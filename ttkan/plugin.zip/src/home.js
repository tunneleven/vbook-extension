load('config.js');

function execute() {
    return Response.success([
        {
            title: "最近更新",
            input: latestPath("1", "30"),
            script: "search.js"
        },
        {
            title: "连载作品",
            input: novelListPath("lianzai", "*", "1", "18"),
            script: "search.js"
        },
        {
            title: "随机推荐",
            input: novelListPath("suixuan", "*", "1", "18"),
            script: "search.js"
        },
        { title: "总排行榜", input: "/novel/rank", script: "search.js" },
        { title: "已完结排行", input: "/novel/rank?completed=1", script: "search.js" },
        { title: "玄幻排行", input: "/novel/rank/xuanhuan", script: "search.js" },
        { title: "都市排行", input: "/novel/rank/dushi", script: "search.js" },
        { title: "仙侠排行", input: "/novel/rank/xianxia", script: "search.js" }
    ]);
}
